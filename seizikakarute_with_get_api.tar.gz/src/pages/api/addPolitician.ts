// API route to add a new politician to Airtable
// This endpoint accepts POST requests with a JSON body containing
// `name`, `party`, `birthDate`, and `age`. It forwards the data to
// the Airtable REST API using credentials stored in environment
// variables. If successful, it returns the created record from
// Airtable. See README or docs for more details.

import type { NextApiRequest, NextApiResponse } from 'next'

interface AddPoliticianRequest {
  name: string
  party: string
  birthDate: string
  age: number
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // このエンドポイントでは POST だけでなく GET も受け付ける。
  // GET の場合はクエリパラメータから値を取得し、POST の場合はリクエストボディから取得。
  const method = req.method?.toUpperCase()

  let name: string | undefined
  let party: string | undefined
  let birthDate: string | undefined
  let age: number | undefined

  if (method === 'GET') {
    // クエリは文字列または配列になり得るので文字列に変換
    const q = req.query
    name = Array.isArray(q.name) ? q.name[0] : q.name
    party = Array.isArray(q.party) ? q.party[0] : q.party
    birthDate = Array.isArray(q.birthDate) ? q.birthDate[0] : q.birthDate
    const ageParam = Array.isArray(q.age) ? q.age[0] : q.age
    age = ageParam ? Number(ageParam) : undefined
  } else if (method === 'POST') {
    const body = req.body as Partial<AddPoliticianRequest>
    name = body.name
    party = body.party
    birthDate = body.birthDate
    age = typeof body.age === 'number' ? body.age : undefined
  } else {
    res.setHeader('Allow', ['GET', 'POST'])
    return res.status(405).json({ error: 'Method Not Allowed' })
  }

  if (!name || !party || !birthDate || typeof age !== 'number') {
    return res.status(400).json({ error: 'Missing required fields' })
  }

  try {
    const baseId = process.env.AIRTABLE_BASE_ID
    const tableName = process.env.AIRTABLE_TABLE_NAME || ''
    const apiKey = process.env.AIRTABLE_API_KEY

    if (!baseId || !tableName || !apiKey) {
      return res.status(500).json({ error: 'Airtable credentials are not configured' })
    }

    const url = `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}`
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fields: {
          名前: name,
          政党: party,
          生年月日: birthDate,
          満年齢: age,
        },
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      const message = data?.error?.message || 'Failed to create record'
      return res.status(response.status).json({ error: message })
    }

    return res.status(200).json(data)
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unknown error' })
  }
}